---------
answers
---------

Le Tp va uniquement jusque les 7 premiers tests, et ne va pas jusqu'a l'insertion dans l'ordre des éléments.

Pour la fonction l'impression depuis la fin, on a dès la première version implémenté cela de telle sorte que l'itérateur se place en fin de liste avec l'utilisation du second paramètre. Du coup il n'y a pas de première version.

Sinon rien d'autre à signaler
