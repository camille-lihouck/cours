------------------
List Iterator
------------------

.. automodule:: listiterator
   :members:
