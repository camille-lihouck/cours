----------
sorting
----------

  .. automodule:: sorting
     :members:
