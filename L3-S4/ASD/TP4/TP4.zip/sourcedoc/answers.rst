-----------
answers
-----------


Le module bloomfilter
======================

Pour un bloomfilter de taille 2² on arrive fréquement a des faux positifs avec 8 fonctions de hachages. Pour une taille de 2 c'est quasiment systèmatique. En terme de probabilité, si on a une taille de bloomfilter plus petit que le nombre de fonction de hachage.
