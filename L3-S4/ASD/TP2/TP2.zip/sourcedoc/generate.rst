------------
generate
------------

  .. automodule:: generate
     :members:
