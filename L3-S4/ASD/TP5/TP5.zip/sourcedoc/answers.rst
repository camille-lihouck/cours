---------------
answers
---------------


Etat du TP, ce tp a été à peine commencé et ne contient que la déclaration des arbres 1 2 et 3.




