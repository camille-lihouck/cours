Le quicksort fonctionne sur les tableaux d'entiers pour le compiler lancer la commande:
makefile Programme.

Les structures de données pour les nominés ont étés réalisées, mais il n'est pas possible de lire un fichier depuis l'entrée standart.

Le reste du TP n'as pas été réalisé.
